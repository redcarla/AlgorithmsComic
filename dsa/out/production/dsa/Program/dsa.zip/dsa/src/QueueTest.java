import org.junit.Before;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class QueueTest {
    DcChar test = new DcChar();
    DcChar test2 = new DcChar();
    Queue q;

    public QueueTest() {
        q = new Queue();
    }

    @Before
    public void setup() throws Exception{


    }

    @Test
    void enqueue() {
        test.setName("Ramon");
        q.enqueue(test);
        DcChar t = (DcChar) q.dequeue();
        assertEquals(t, test);
    }

    @Test
    public void dequeue() {
        test.setName("Ramon");
        assertEquals("Ramon", test.getName());
    }
}

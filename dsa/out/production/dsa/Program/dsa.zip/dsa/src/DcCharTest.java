import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Test;

import javax.swing.plaf.synth.SynthLookAndFeel;

import static org.junit.jupiter.api.Assertions.*;

class DcCharTest {
    DcChar test = new DcChar();
    DcChar test2 = new DcChar();
    @Before
    public void setup() throws Exception{


    }

    @Test
    void setName() {
        test.setName("Ramon");
        assertEquals("Ramon", test.getName());
    }

    @Test
    public void getName() {
        test.setName("Ramon");
        assertEquals("Ramon", test.getName());
    }


    @Test
    void setId() {
        test.setId("Ramon");
        assertEquals("Ramon", test.getId());
    }

    @Test
    void getId() {
        test.setId("Ramon");
        assertEquals("Ramon", test.getId());
    }

    @Test
    void setSex() {
        test.setSex("Man");
        assertEquals("Man", test.getSex());
    }

    @Test
    void getSex() {
        test.setSex("Man");
        assertEquals("Man", test.getSex());
    }

    @Test
    void setAlign() {
        test.setAlign("Good");
        assertEquals("Good", test.getAlign());
    }

    @Test
    void getAlign() {
        test.setAlign("Good");
        assertEquals("Good", test.getAlign());
    }

    @Test
    void setEye() {
        test.setEye("red");
        assertEquals("red", test.getEye());
    }

    @Test
    void getEye() {
        test.setEye("red");
        assertEquals("red", test.getEye());
    }

    @Test
    void setHair() {
        test.setHair("red");
        assertEquals("red", test.getHair());
    }

    @Test
    void getHair() {
        test.setHair("red");
        assertEquals("red", test.getHair());
    }

    @Test
    void setGSM() {
        test.setHair("red");
        assertEquals("red", test.getHair());
    }

    @Test
    void getGSM() {
        test.setGSM("red");
        assertEquals("red", test.getGSM());
    }

    @Test
    void setAlive() {
        test.setAlive("yes");
        assertEquals("yes", test.getAlive());
    }

    @Test
    void getAlive() {
        test.setAlive("yes");
        assertEquals("yes", test.getAlive());
    }

    @Test
    void setappearance() {
        test.setappearance("Ugly");
        assertEquals("Ugly", test.getAppearance());
    }

    @Test
    void getAppearance() {
        test.setappearance("Ugly");
        assertEquals("Ugly", test.getAppearance());
    }

    @Test
    void setFAppearance() {
        test.setFAppearance("Ugly");
        assertEquals("Ugly", test.getFAppearance());
    }

    @Test
    void getFAppearance() {
        test.setFAppearance("Ugly");
        assertEquals("Ugly", test.getFAppearance());
    }

    @Test
    void setYear() {
        test.setYear("1997");
        assertEquals("1997", test.getYear());
    }

    @Test
    void getYear() {
        test.setYear("1997");
        assertEquals("1997", test.getYear());
    }


    @Test
    void compareTo() {
        test.setName("Ramon");
        test2.setName("Carla");
        int result = test.compareTo(test2);
        assertEquals(result,test.compareTo(test2));
    }

}